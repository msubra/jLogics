	jLogics - Java Digital Logic Circuit Simulator
	==============================================

	To start jLogics, just unzip all the files into a folder and run the "run.bat" file or double click the "jLogics.jar" File in directory.

jLogics is built using the following tools.
	* Sun Java
	* XML
	* xstream
	* gnuprolog - prolog-java interface